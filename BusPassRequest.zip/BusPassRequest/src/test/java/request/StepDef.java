package request;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private WebDriver webDriver;
	private WebElement element;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		webDriver=new ChromeDriver();
	}
	
	@Given("^User Details$")
	public void user_Details() throws Throwable {
		webDriver.get("http://localhost:8081/BusPassRequest/pages/requestform.html");
	}

	@When("^Submit valid details$")
	public void submit_valid_details() throws Throwable {
		webDriver.findElement(By.name("empid")).sendKeys("12345_IN");
		webDriver.findElement(By.name("fname")).sendKeys("Tom");
		webDriver.findElement(By.name("lname")).sendKeys("Jerry");
		webDriver.findElement(By.name("emailid")).sendKeys("tom@gmail.com");
		Select designation=new Select(webDriver.findElement(By.name("designation")));
		designation.selectByVisibleText("Software Engineer");
		webDriver.findElement(By.id("female")).click();
		webDriver.findElement(By.name("address")).sendKeys("Chennai");
		webDriver.findElement(By.name("doj")).sendKeys("28/11/2018");
		Select location=new Select(webDriver.findElement(By.name("location")));
		location.selectByVisibleText("Chennai MIPL");
		Select pickupLocation=new Select(webDriver.findElement(By.name("pickuplocation")));
		pickupLocation.selectByVisibleText("Chengalpattu");
		webDriver.findElement(By.name("pickuptime")).sendKeys("01:00 PM");
		 Thread.sleep(1000);
		 element=webDriver.findElement(By.name("submit"));
	      element.submit();
	}

	@Then("^Navigate to Request Page$")
	public void navigate_to_Request_Page() throws Throwable {
		webDriver.navigate().to("http://localhost:8081/BusPassRequest/index.html"); 
		  Thread.sleep(1000);
	}


}
