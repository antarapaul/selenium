package login;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	private WebDriver webDriver;
	private WebElement element;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		webDriver=new ChromeDriver();
	}



	@Given("^Open Login Page$")
	public void open_Login_Page() throws Throwable {
		webDriver.get("http://localhost:8081/BusPassRequest/index.html"); 
	}

	@When("^Submit after validating username and password$")
	public void submit_after_validating_username_and_password() throws Throwable {
		webDriver.findElement(By.name("Username")).sendKeys("antara");
		webDriver.findElement(By.name("Password")).sendKeys("antara123");
	}

	@Then("^Open the menu page$")
	public void open_the_menu_page() throws Throwable {
		/*assertEquals( "http://localhost:8081/BusPassRequest/index.html", webDriver.getCurrentUrl());
		element.findElement(By.name("login"));

		element.submit();*/
		webDriver.navigate().to("http://localhost:8081/BusPassRequest/pages/menu.html");
		   
	}



}
