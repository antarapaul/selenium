package addroute;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private WebDriver webDriver;
	private WebElement element;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		webDriver=new ChromeDriver();
	}
	
	@Given("^routepath,total seat,occupied seat,bus no,driver name,total km$")
	public void routepath_total_seat_occupied_seat_bus_no_driver_name_total_km() throws Throwable {
	    webDriver.get("http://localhost:8081/BusPassRequest/pages/newroute.html");
	    webDriver.findElement(By.name("routepath")).sendKeys("hyd-kolkata");
	    webDriver.findElement(By.name("totalseats")).sendKeys("50");
	    webDriver.findElement(By.name("occupiedseats")).sendKeys("20");
	    webDriver.findElement(By.name("busno")).sendKeys("TN-2345");
	    webDriver.findElement(By.name("drivername")).sendKeys("arimdam");
	    webDriver.findElement(By.name("totalkm")).sendKeys("59");
	}

	@When("^Add routes after taking inputs$")
	public void add_routes_after_taking_inputs() throws Throwable {
		element=webDriver.findElement(By.name("addnewroute"));
	      element.submit();
	}

	@Then("^go to menu page$")
	public void go_to_menu_page() throws Throwable {
	   webDriver.navigate().to("http://localhost:8081/BusPassRequest/pages/newSuccess.html");
	   
	}



}
